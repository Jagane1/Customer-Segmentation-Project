# Load the data

import pandas as pd

df = pd.read_csv('/Users/jagadeeshnellore/Intership Major Project/customer_segmentation_ecommerce.csv')
print(df.head())


# Explore the data
print(df.info())


print(df.describe())
print(df.isnull().sum())


#Preprocess the data

from sklearn.preprocessing import StandardScaler

numerical_features = ['Age', 'Annual_Income', 'Spending_Score', 'Purchase_Frequency', 'Avg_Order_Value', 'Recency']
df_numerical = df[numerical_features]

scaler = StandardScaler()
df_scaled = scaler.fit_transform(df_numerical)

df_scaled = pd.DataFrame(df_scaled, columns=numerical_features)
print(df_scaled.head())

#Apply clustering

from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
kmeans.fit(df_scaled)
df['Cluster'] = kmeans.labels_
print(df.head())

#Dimensionality reduction with pca

from sklearn.decomposition import PCA

pca = PCA(n_components=2, random_state=42)
df_pca = pca.fit_transform(df_scaled)

df_pca = pd.DataFrame(df_pca, columns=['PCA1', 'PCA2'])
print(df_pca.head())

#Analyze clusters

cluster_characteristics = df.groupby('Cluster')[numerical_features].mean()
print(cluster_characteristics)

#Visualize clusters

import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(10, 7))
sns.scatterplot(x='PCA1', y='PCA2', hue=df['Cluster'], data=df_pca, palette='viridis', s=100)
plt.title('Customer Clusters (PCA-reduced)', fontsize=16)
plt.xlabel('Principal Component 1', fontsize=12)
plt.ylabel('Principal Component 2', fontsize=12)
plt.grid(True)
plt.show()